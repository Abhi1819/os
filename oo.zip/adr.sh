#!/bin/bash
getname()

{
	read -p "Enter your name " name
	echo  "Hello $name";
}

getname()
