#include<algorithm> // for find function
#include<deque> // doubly ended queue
#include<iostream> //input output stream
#include<unordered_set> // for pageSet
using namespace std;
int main(){

    int frame_size= 4;
    int arr[]={7,0,1,2,0,3,0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int page_fault = 0 , page_hits = 0 ;

    deque<int> q(frame_size);
    unordered_set<int> pageSet;
    deque<int> :: iterator itr;

    for (int i: arr){
        itr = find(q.begin(),q.end(),i);

        if (!(itr != q.end())){

            ++page_fault;

            if (q.size() == frame_size){

                //q is full now .. remove first one 
                pageSet.erase(q.front());
                q.pop_front();
                q.push_back(i);
                pageSet.insert(i);

            }else{

                q.push_back(i);
                pageSet.insert(i);
            }
        }else{
            q.erase(itr);
            q.push_back(i);

            pageSet.erase(i);
            pageSet.insert(i);
            ++page_hits;

        }
    }

    cout << "page faults: " << page_fault;
    cout << "page hits: " << page_hits;


}