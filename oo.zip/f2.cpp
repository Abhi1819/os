#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

int main() {
    char * myfifo = "/home/remnux/os/s1.txt";
    mkfifo(myfifo,0666);
    char arr1[80],arr2[80];
    int fd;
    while(1){
        fd = open(myfifo,O_RDONLY);
        read(fd,arr1,80);
        printf("User1: %s",arr1);
        close(fd);

    }

   
    return 0;
}
