// Caller program
#include <unistd.h>

int main() {
    char *program_path = "./a.out";
    char *args[] = {program_path, "42", "55", "13", NULL};

    execv(program_path, args);

    // If execv fails
    printf("execv");
    return 1;
}
