#include<stdio.h>
#include<stdlib.h>

int main(){
    int temp;
    int arr[]={1,3,6,3,6,34,6,36};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("sorted: ");
    for (int i=0;i<size;i++){
        if (arr[i] < arr[i+1]){
            arr[i] = temp;
            temp = arr[i+1];
            arr[i+1] = temp;
        }

    }


    return 0;
}