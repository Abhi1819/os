#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
    int fd;
    char *fifoPath = "/tmp/myfifo";
    mkfifo(fifoPath, 0666);

    char message[80];

    printf("FIFO Writer Process\n");

    while (1) {
        // Open FIFO for write-only
        fd = open(fifoPath, O_WRONLY);

        // Get user input
        printf("Enter a message: ");
        fgets(message, sizeof(message), stdin);

        // Write the message to FIFO
        write(fd, message, strlen(message) + 1);
        close(fd);
    }

    return 0;
}
