#include<algorithm> // for find function
#include<deque> // doubly ended queue
#include<iostream> //input output stream
#include<unordered_set> // for pageSet
int main(){
    int frame_size= 4;
    
}